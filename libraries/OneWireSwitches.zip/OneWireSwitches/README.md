# Arduino-OneWireSwitches
An Arduino library to read multiple switches with only one analog input
